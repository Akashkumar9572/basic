import React from 'react'

const Events = () => {
  return (
    <div className="center h-screen flex-col">
    
    <div className="text-3xl">Event Page</div>
    
        </div>
  )
}

export default Events