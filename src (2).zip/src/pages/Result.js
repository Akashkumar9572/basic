import React from 'react'

const Result = () => {
  return (
    <div className="center h-screen flex-col">
    
    <div className="text-3xl">Result is comming soon...</div>
    
        </div>
  )
}

export default Result