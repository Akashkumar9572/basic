import Navbar from './components/Navbar';
import logo from './logo.svg';
import Campus from './pages/Campus';
import Events from './pages/Events';
import Home from './pages/Home';
import { Routes,Route } from 'react-router-dom';
import Syllabus from './pages/Syllabus';
import Result from './pages/Result';
import ExamPage from './pages/ExamPage';
import Counter from './app/Counter';
import Projects from './pages/Projects';
import Calculator from './app/Calculator';
import Mode from './app/Mode';
import About from './pages/About';

function App() {
  return (
    <> 
    <Navbar/> 
        {/* <Routes>
        <Route path="/" element={<Home/>}></Route>
      <Route path="/counter" element={<Counter/>}></Route>
      <Route path="/projects" element={<Projects/>}></Route>
      <Route path="/calculator" element={<Calculator/>}></Route>
      <Route path="/mode" element={<Mode/>}></Route>
     </Routes> */}
    
     <About/>
     <Projects/>
    
    

    </>
  );
}

export default App;
