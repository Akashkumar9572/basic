import React from 'react'
import { Link } from 'react-router-dom'

const Projects = () => {
  return (
    <div className='h-screen w-full flex justify-center items-center gap-10'>
        <div className="w-[300px] h-[400px] bg-blue-200 relative">project 1
        <div className="w-7 h-7 absolute z-10"><img src="c:\Users\akash\Desktop\png - Copy.jpg" alt="" /></div>
        </div>
        <div className="w-[300px] h-[400px] bg-blue-200">project 2</div>
        <Link to='/calculator'><div className="w-[300px] h-[400px] bg-blue-200">Calculator</div></Link>
    </div>

  )
}

export default Projects
