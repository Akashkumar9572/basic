import React from 'react'

const Campus = () => {
  return (
    <div className="center h-screen flex-col">
    
    <div className="text-3xl">Campus Page</div>
    
        </div>
  )
}

export default Campus