import React from 'react'

const Syllabus = () => {
  return (
    <div className="center h-screen flex-col">
    
    <div className="text-3xl">Syllabus .. i dont know</div>
    
        </div>
  )
}

export default Syllabus