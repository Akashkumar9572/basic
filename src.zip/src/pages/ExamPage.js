import React from 'react'

const ExamPage = () => {
  return (
    <div className="center h-screen flex-col">
    
    <div className="text-3xl">Exam Page</div>
    
        </div>
  )
}

export default ExamPage